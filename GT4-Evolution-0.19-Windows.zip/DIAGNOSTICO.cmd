@echo off
setlocal
cd /d "%~dp0"
start "" /wait "%~dp0GT4Evolution.exe" --log-file "%~dp0juego.log"
echo Diagnostico guardado en juego.log.
pause
