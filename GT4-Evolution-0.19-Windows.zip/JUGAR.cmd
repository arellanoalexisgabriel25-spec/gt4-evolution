@echo off
setlocal
cd /d "%~dp0"
start "" "%~dp0GT4Evolution.exe"
